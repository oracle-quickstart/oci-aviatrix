# OCI Gov Publishing

## BYOL Controller
- Validate the ocid for controller & gateway through commercial launch
  - Controller: ocid1.image.oc1..aaaaaaaaltulqugc5ygggevy3ig7mv2io75azdareylypx23ezhvonqgrcrq
  - Gateway: ocid1.image.oc1..aaaaaaaaexk7kwjxqv5zi6pbsp5ltnkjdjqgguaurythqtyxrltew4rh7kda
- Update quickstart TF
- Create TF zip artifact
- Create new version of listing
- Update artifact
- Update listing verbage
- Submit for Publishing
- Update Available Shapes (stretch goal)

## PAYG Controller
- Same workflow as BYOL
- Modify pricing